// libraries
#include <MKRNB.h>
#include <PubSubClient.h>

#include "arduino_secrets.h"

#define TRIGGER_PIN 3 
#define ECHO_PIN 5 
#define LED_PIN 6 
#define BUZZER_PIN 1 

//The MKRNB lib needs this even if its blank; My sim card does not require a pin
const char PINNUMBER[] = SECRET_PINNUMBER;

// initialize the library instance
NBClient nbclient;
GPRS gprs;
NB nbAccess;

//MQTT info
const char* mqtt_server = "test.mosquitto.org";
const int port = 1883;

const char* clientID = "";//"MKRNB1500";
const char* topic1 = "/RMIC_G00/alarm_status";
const char* topic2 = "/RMIC_G00/measurement";
const char* topic3 = "/RMIC_G00/enable_alert_sound";

int enable_alert_sound = 0;
bool alarm_status;
int measurement = 0; 
bool publish;

// const char* username = "username";
// const char* password = "password";

//connect the pubsub client
PubSubClient client(nbclient);


void callback(char* topic, byte* payload, unsigned int length) {
  Serial.print("Message Arrived [");
  Serial.print(topic);
  Serial.print("] ");
  for (int i=0;i<length;i++) {
    Serial.print((char)payload[i]);
  }
  Serial.println();
  enable_alert_sound = payload[0]-'0';
  Serial.print("enable_alert_sound: ");
  Serial.println(enable_alert_sound);
}

//connection and reconnection function
void reconnect() {
  alarm_status = false;

  while (!client.connected()) {
    // Attemp to connect
    Serial.println("connection attemp to broker");
    if (client.connect(clientID)) {       //client.connect(clientID,username,password)
      Serial.println("Connected");
      client.publish(topic1, "0");
      client.publish(topic2, "0");
      client.subscribe(topic3);
    } else {
      Serial.print("Failed, rc=");
      Serial.print(client.state());
      Serial.println(" try again in 2 seconds");
      // Wait 2 seconds before retrying
      delay(2000);
    }
  }
}

void setup() {
  //Initialize I/O pins
  pinMode(TRIGGER_PIN, OUTPUT); // D3 TRIGGER
  pinMode(ECHO_PIN, INPUT); // D5 ECHO
  pinMode(LED_PIN, OUTPUT); // D6 LED 
  pinMode(BUZZER_PIN, OUTPUT); //D1 = BUZZER

  // initialize serial communications and wait for port to open:
  Serial.begin(9600);
  while (!Serial) {
    ; // wait for serial port to connect. Needed for native USB port only
  }

  Serial.println("Starting Arduino MQTT client.");
  // connection state
  boolean connected = false;

  // After starting the modem with NB.begin()
  // attach to the GPRS network with the APN, login and password
  while (!connected) {
    if ((nbAccess.begin(PINNUMBER) == NB_READY) &&
        (gprs.attachGPRS() == GPRS_READY)) {
      connected = true;
    } else {
      Serial.println("Not connected");
      delay(1000);
    }
  }

  Serial.println("modem started && attached to GPRS network");

  client.setServer(mqtt_server, port);
  client.setCallback(callback);
  Serial.println("server details set");
}

int getdistancelvl(){
  int duration, distance;
  // Clears the D3 condition
  digitalWrite(TRIGGER_PIN, LOW);
  delayMicroseconds(2);
  // Sets the D3 HIGH (ACTIVE) for 10 microseconds
  digitalWrite(TRIGGER_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIGGER_PIN, LOW);
  // Reads the D5, returns the sound wave travel time in microseconds
  duration = pulseIn(ECHO_PIN, HIGH);
  // Calculating the distance
  distance = duration * 0.034 / 2; // Speed of sound wave divided by 2 (go and back)
  Serial.print("Distance: ");
  Serial.print(distance);
  Serial.println(" cm");
  if(distance < 20) { 
    return 1;
  }

  return 0;
}

void loop() {
  //if the connection drops then reconnect it
  if (!client.connected()) {
    reconnect();
  }

  Serial.print("Before client.loop()");

  //This should be called regularly to allow the client to process incoming messages
  //and maintain its connection to the server.
  client.loop();
  
  Serial.print("After client.loop()");

  bool alarm_status_new;
  if (getdistancelvl() == 1 ) {
    alarm_status_new = true;

    digitalWrite(LED_PIN, HIGH);
    Serial.println("LED ON");

    if ( enable_alert_sound == 1 ) {
      Serial.println("Buzz!");
      tone(BUZZER_PIN,450); 
      delay(1000);
      noTone(BUZZER_PIN);    
    }
    else {
      Serial.println("No Buzz!");
      delay(1000);
      noTone(BUZZER_PIN);      
    }
  }
  else {
    alarm_status_new = false;
    digitalWrite(LED_PIN, LOW);
  }

  if (alarm_status_new != alarm_status) {
    publish = true;
    if (alarm_status_new ) measurement++;
    alarm_status = alarm_status_new;
  } else {
    publish = false;
  }

  char alarm_status_pl[2] = "0";
  if (publish) {
    if (alarm_status) {
      alarm_status_pl[0] = '1';
    } else {
      alarm_status_pl[0] = '0';
    }
    if ( client.publish(topic1, alarm_status_pl) ) {
        Serial.print("Message Published [");
    }
    else {
        Serial.print("Publish Error [");
    } 
    Serial.print(topic1);
    Serial.print(", ");
    Serial.print(alarm_status_pl);
    Serial.println("]: ");
    Serial.println(client.state());   

    if ( client.publish(topic2, String(measurement).c_str()) ) {
        Serial.print("Message Published [");
     }
    else {
        Serial.print("Publish Error [");
    } 
    Serial.print(topic2);
    Serial.print(", ");
    Serial.print(measurement);
    Serial.println("]: ");
    Serial.println(client.state());   
 

  }

  Serial.println("Checking for movement...");
  delay(2500);
  
}
